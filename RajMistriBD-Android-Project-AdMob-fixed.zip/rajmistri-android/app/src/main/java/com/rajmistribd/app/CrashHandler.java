package com.rajmistribd.app;

import android.content.Context;
import android.content.Intent;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * অ্যাপ ক্র্যাশ করলে ডিফল্টভাবে Android পুরো অ্যাপ সাইলেন্টলি বন্ধ করে হোমস্ক্রিনে
 * পাঠিয়ে দেয় — কোনো এরর মেসেজ চোখে পড়ে না। এই ক্লাসটা সেই ডিফল্ট আচরণ বদলে দেয়:
 * ক্র্যাশ হওয়া মাত্র আসল এরর (স্ট্যাক ট্রেস) সহ একটা স্ক্রিন দেখায়, যাতে সমস্যাটা
 * ধরা যায়।
 */
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String EXTRA_STACK_TRACE = "extra_stack_trace";

    private final Context appContext;
    private final Thread.UncaughtExceptionHandler previousHandler;

    private CrashHandler(Context appContext, Thread.UncaughtExceptionHandler previousHandler) {
        this.appContext = appContext.getApplicationContext();
        this.previousHandler = previousHandler;
    }

    public static void install(Context context) {
        Thread.UncaughtExceptionHandler existing = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(context, existing));
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            String trace = sw.toString();

            Intent intent = new Intent(appContext, CrashActivity.class);
            intent.putExtra(EXTRA_STACK_TRACE, trace);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            appContext.startActivity(intent);
        } catch (Throwable ignored) {
            // চেষ্টা করেও যদি স্ক্রিন দেখানো না যায়, তাহলে অন্তত অ্যাপটা যেন স্বাভাবিকভাবেই বন্ধ হয়
        }

        // নির্দিষ্ট করে প্রসেসটা বন্ধ করে দেওয়া, যাতে সিস্টেম নিজে থেকে একটা
        // এলোমেলো অবস্থায় অ্যাপটাকে না রাখে
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(10);
    }

    public static String getStackTraceExtra(Intent intent) {
        return intent.getStringExtra(EXTRA_STACK_TRACE);
    }
}
