package com.rajmistribd.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CrashActivity extends AppCompatActivity {

    private String stackTrace = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash);

        stackTrace = CrashHandler.getStackTraceExtra(getIntent());
        if (stackTrace == null) {
            stackTrace = "কোনো এরর তথ্য পাওয়া যায়নি।";
        }

        TextView traceView = findViewById(R.id.crashTraceText);
        traceView.setText(stackTrace);

        Button copyButton = findViewById(R.id.crashCopyButton);
        copyButton.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("crash log", stackTrace));
                Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show();
            }
        });

        Button closeButton = findViewById(R.id.crashCloseButton);
        closeButton.setOnClickListener(v -> finish());
    }
}
