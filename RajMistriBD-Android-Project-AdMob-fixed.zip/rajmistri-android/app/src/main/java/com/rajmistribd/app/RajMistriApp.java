package com.rajmistribd.app;

import android.app.Application;

/**
 * এখানে অ্যাপ চালু হওয়ার একদম শুরুতেই একটা গ্লোবাল ক্র্যাশ হ্যান্ডলার বসানো হয়েছে।
 * অ্যাপ যদি কোনো কারণে ক্র্যাশ করে (যেমন এখন হচ্ছে বলে জানিয়েছেন), তাহলে সাথে সাথে
 * বন্ধ হয়ে হোমস্ক্রিনে চলে যাওয়ার বদলে একটা স্ক্রিনে আসল এরর মেসেজটা (স্ট্যাক ট্রেস)
 * দেখাবে। সেই স্ক্রিনের লেখাটা কপি করে পাঠালে ক্র্যাশের আসল কারণ বের করা যাবে।
 */
public class RajMistriApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashHandler.install(this);
    }
}
