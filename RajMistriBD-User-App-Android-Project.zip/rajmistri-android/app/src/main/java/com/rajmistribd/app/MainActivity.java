package com.rajmistribd.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.FrameLayout;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "RajMistriBD";
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PERMISSION_REQUEST_CODE = 4321;
    private static final int FILE_CHOOSER_REQUEST_CODE = 5150;

    // AdMob: "রোবটের এড দেখে স্টার জিতুন" স্ক্রিনের জন্য rewarded ad
    // Google-এর অফিসিয়াল টেস্ট আইডি (debug build-এ ব্যবহার হবে, নিজে ক্লিক করে টেস্ট করলে ব্যান হবে না)
    private static final String TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917";
    // আপনার আসল (real) AdMob রিওয়ার্ডেড আইডি (শুধু release build/Play Store-এ ব্যবহার হবে)
    private static final String REAL_REWARDED_AD_UNIT_ID = "ca-app-pub-6847744858575721/5161954619";
    // BuildConfig.DEBUG = true হলে টেস্ট আইডি, false (release) হলে রিয়েল আইডি — অটোমেটিক সুইচ
    private static final String REWARDED_AD_UNIT_ID =
            BuildConfig.DEBUG ? TEST_REWARDED_AD_UNIT_ID : REAL_REWARDED_AD_UNIT_ID;

    // AdMob: নিচে ফিক্সড ব্যানার অ্যাড (সবসময় স্ক্রিনের নিচে দেখা যাবে)
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    // ⚠️ TODO: AdMob কনসোল থেকে নতুন "Banner" ইউনিট বানিয়ে এখানে সেই রিয়েল আইডিটা বসান
    private static final String REAL_BANNER_AD_UNIT_ID = "ca-app-pub-6847744858575721/8772529584";
    private static final String BANNER_AD_UNIT_ID =
            BuildConfig.DEBUG ? TEST_BANNER_AD_UNIT_ID : REAL_BANNER_AD_UNIT_ID;

    // AdMob: ফিডের ভেতরে বসানো নেটিভ ইনলাইন ব্যানার (প্রতি ৩টা পোস্ট পরপর, WebView-এর "স্পন্সরড" স্লটের উপরে)
    private static final String TEST_INLINE_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    // ⚠️ TODO: AdMob কনসোল থেকে নতুন "Banner" ইউনিট বানিয়ে এখানে সেই রিয়েল আইডিটা বসান (banner-এর থেকে আলাদা ইউনিট রাখা ভালো)
    private static final String REAL_INLINE_AD_UNIT_ID = "ca-app-pub-6847744858575721/8772529584";
    private static final String INLINE_AD_UNIT_ID =
            BuildConfig.DEBUG ? TEST_INLINE_AD_UNIT_ID : REAL_INLINE_AD_UNIT_ID;

    private AdView adViewBanner;
    private AdView adViewInline;

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;

    private RewardedAd rewardedAd;
    private boolean isLoadingRewardedAd = false;

    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private long backPressedAt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Switch from splash theme to the normal app theme before inflating.
        setTheme(R.style.Theme_RajMistri);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        progressBar = findViewById(R.id.progressBar);

        requestNeededPermissions();
        setupWebView();

        MobileAds.initialize(this, initializationStatus -> { });

        try {
            adViewBanner = findViewById(R.id.adViewBanner);
            if (adViewBanner != null) {
                adViewBanner.setAdUnitId(BANNER_AD_UNIT_ID);
                adViewBanner.loadAd(new AdRequest.Builder().build());
            }
        } catch (Exception e) {
            Log.e(TAG, "Banner ad init failed, continuing without banner", e);
        }
        try {
            adViewInline = findViewById(R.id.adViewInline);
            if (adViewInline != null) {
                adViewInline.setAdUnitId(INLINE_AD_UNIT_ID);
                adViewInline.loadAd(new AdRequest.Builder().build());
            }
        } catch (Exception e) {
            Log.e(TAG, "Inline ad init failed, continuing without inline ad", e);
        }
        webView.addJavascriptInterface(new AndroidAdBridge(), "AndroidAd");
        webView.addJavascriptInterface(new AndroidInlineAdBridge(), "AndroidInlineAd");
        try {
            loadRewardedAd();
        } catch (Exception e) {
            Log.e(TAG, "Rewarded ad preload failed, continuing", e);
        }

        swipeRefresh.setOnRefreshListener(() -> webView.reload());

        if (isNetworkAvailable()) {
            webView.loadUrl(APP_URL);
        } else {
            showNoInternetDialog();
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // প্রথমে ওয়েব অ্যাপকে জিজ্ঞেস করা হয় ভেতরে কোনো মডাল/ওভারলে খোলা আছে কিনা,
                // বা ইন-অ্যাপ নেভিগেশন স্ট্যাকে পেছনে যাওয়ার কিছু আছে কিনা। থাকলে সেটাই হ্যান্ডেল
                // করবে (true রিটার্ন করবে) — তখন অ্যাপ থেকে বের হবে না।
                webView.evaluateJavascript(
                        "(function(){ try { return typeof handleAndroidBack==='function' ? handleAndroidBack() : false; } catch(e){ return false; } })();",
                        value -> {
                            boolean handledInPage = "true".equals(value);
                            if (handledInPage) return;

                            if (webView.canGoBack()) {
                                webView.goBack();
                            } else {
                                if (backPressedAt + 2000 > System.currentTimeMillis()) {
                                    finish();
                                } else {
                                    Toast.makeText(MainActivity.this, R.string.exit_confirm, Toast.LENGTH_SHORT).show();
                                    backPressedAt = System.currentTimeMillis();
                                }
                            }
                        }
                );
            }
        });
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void setupWebView() {
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        // ⚠️ ফিক্স: LOAD_DEFAULT ব্যবহার করলে WebView পুরনো index.html ক্যাশে রেখে দিতে পারে,
        // ফলে নতুন APK রিবিল্ড/ইনস্টল করার পরও অ্যাপের ভেতরে পুরনো ভার্সনই দেখা যায়।
        // যেহেতু এই অ্যাপের সব কনটেন্ট লোকাল assets থেকে আসে (নেটওয়ার্ক থেকে না), তাই
        // ক্যাশ পুরোপুরি বন্ধ রাখলে পারফরম্যান্সে কোনো ক্ষতি নেই, কিন্তু সবসময় সবচেয়ে নতুন কোড লোড হবে।
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // ⚠️ ফিক্স: আগের ভার্সনগুলোতে যেসব ইউজারের ফোনে ইতিমধ্যে পুরনো index.html ক্যাশ হয়ে আছে,
        // তাদের জন্য একবার সম্পূর্ণ WebView ক্যাশ পরিষ্কার করে দেওয়া হচ্ছে যাতে তারাও নতুন কোড দেখতে পান।
        webView.clearCache(true);

        webView.setWebViewClient(new WebViewClientCompat() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(@NonNull WebView view, @NonNull WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(@NonNull WebView view, @NonNull WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null) return false;

                if (scheme.equals("http") || scheme.equals("https")) {
                    // Keep app traffic inside the WebView; open other https links externally
                    // only if they leave the app's own host.
                    if ("appassets.androidplatform.net".equals(uri.getHost())) {
                        return false;
                    }
                    view.loadUrl(uri.toString());
                    return true;
                }

                // tel:, mailto:, whatsapp:, geo: etc -> hand off to the system.
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.w(TAG, "No app found to handle: " + uri);
                }
                return true;
            }

            @Override
            public void onPageFinished(@NonNull WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress >= 100) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            // Gallery + camera picker for <input type="file" accept="image/*">
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallbackParam,
                                              FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackParam;

                // ক্যামেরা ইন্টেন্ট সেটআপ করার সময় কোনো সমস্যা হলেও (FileProvider/storage
                // সংক্রান্ত) যেন পুরো ফাংশনটা ক্র্যাশ না করে — শুধু ক্যামেরা অপশনটা বাদ
                // দিয়ে গ্যালারি অপশন দিয়ে এগিয়ে যায়।
                Intent takePictureIntent = null;
                if (hasCameraPermission()) {
                    try {
                        File photoFile = createImageFile();
                        if (photoFile != null) {
                            cameraPhotoPath = "file:" + photoFile.getAbsolutePath();
                            Uri photoUri = FileProvider.getUriForFile(MainActivity.this,
                                    getApplicationContext().getPackageName() + ".fileprovider", photoFile);
                            takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "Camera intent setup failed, continuing with gallery only", ex);
                        takePictureIntent = null;
                    }
                }

                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("image/*");
                contentSelectionIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "ছবি নির্বাচন করুন");
                if (takePictureIntent != null) {
                    chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{takePictureIntent});
                }

                try {
                    startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    // chooser খোলা যায়নি — সাধারণ গ্যালারি ইন্টেন্ট দিয়ে আরেকবার চেষ্টা
                    Log.e(TAG, "Could not open chooser, falling back to plain gallery intent", e);
                    try {
                        startActivityForResult(contentSelectionIntent, FILE_CHOOSER_REQUEST_CODE);
                    } catch (Exception e2) {
                        // এটাও ব্যর্থ হলে অ্যাপ বন্ধ না করে শুধু জানিয়ে দেওয়া হয়, আর JS-এর
                        // ফাইল-পিকার প্রমিসটা resolve করে দেওয়া হয় যাতে সেটা আটকে না থাকে
                        Log.e(TAG, "Could not open any image picker", e2);
                        Toast.makeText(MainActivity.this, "ছবি বাছাইয়ের কোনো অ্যাপ খুঁজে পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
                        if (filePathCallback != null) {
                            filePathCallback.onReceiveValue(null);
                            filePathCallback = null;
                        }
                    }
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // Auto-grant in-page permission prompts (e.g. getUserMedia) that map to
                // permissions we already hold; otherwise deny.
                runOnUiThread(() -> {
                    ArrayList<String> granted = new ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && hasCameraPermission()) {
                            granted.add(resource);
                        }
                    }
                    if (!granted.isEmpty()) {
                        request.grant(granted.toArray(new String[0]));
                    } else {
                        request.deny();
                    }
                });
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "ফাইল ডাউনলোড করা যায়নি", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            try {
                if (resultCode == RESULT_OK) {
                    if (data == null || (data.getData() == null && data.getClipData() == null)) {
                        // Photo was taken with the camera.
                        if (cameraPhotoPath != null) {
                            results = new Uri[]{Uri.parse(cameraPhotoPath)};
                        }
                    } else if (data.getClipData() != null) {
                        // Multiple images selected from the gallery.
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else {
                        String dataString = data.getDataString();
                        if (dataString != null) {
                            results = new Uri[]{Uri.parse(dataString)};
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error reading picked image result", e);
                results = null;
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "RAJMISTRI_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) {
            storageDir.mkdirs();
        }
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        ArrayList<String> toRequest = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            toRequest.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!toRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return capabilities != null && (
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    private void showNoInternetDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.no_internet_title)
                .setMessage(R.string.no_internet_message)
                .setCancelable(false)
                .setPositiveButton(R.string.retry, (dialog, which) -> {
                    if (isNetworkAvailable()) {
                        webView.loadUrl(APP_URL);
                    } else {
                        showNoInternetDialog();
                    }
                })
                .show();
    }

    // ============== AdMob Rewarded Ad ("রোবটের এড দেখে স্টার জিতুন") ==============

    /** WebView-এর JS থেকে কল করার জন্য ব্রিজ। index.html-এর startRewardedAd() এটাকে ব্যবহার করে। */
    private class AndroidAdBridge {
        @JavascriptInterface
        public void showRewardedAd(final int idx, final int seconds) {
            runOnUiThread(() -> showRewardedAdForIndex(idx));
        }
    }

    // ============== ফিডের ভেতরের নেটিভ ইনলাইন ব্যানার (WebView "স্পন্সরড" স্লটের উপর বসানো) ==============

    /** WebView-এর JS (index.html-এর updateInlineAdPosition()) এই ব্রিজ কল করে ad-slot-inner
     *  div-টার স্ক্রিন-পজিশন (CSS px) পাঠায়, আর আমরা সেই পজিশনে আসল AdMob ব্যানারটা বসিয়ে দিই। */
    private class AndroidInlineAdBridge {
        @JavascriptInterface
        public void showAt(final float topPx, final float leftPx, final float widthPx) {
            runOnUiThread(() -> {
                if (adViewInline == null) return;
                float density = getResources().getDisplayMetrics().density;
                float adWidthDp = 320f; // AdSize.BANNER-এর প্রস্থ
                float centeredLeftPx = leftPx + Math.max(0f, (widthPx - adWidthDp) / 2f);
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) adViewInline.getLayoutParams();
                lp.topMargin = Math.round(topPx * density);
                lp.leftMargin = Math.round(centeredLeftPx * density);
                adViewInline.setLayoutParams(lp);
                adViewInline.setVisibility(View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void hide() {
            runOnUiThread(() -> {
                if (adViewInline != null) adViewInline.setVisibility(View.GONE);
            });
        }
    }

    private void loadRewardedAd() {
        if (isLoadingRewardedAd || rewardedAd != null) return;
        isLoadingRewardedAd = true;
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        isLoadingRewardedAd = false;
                        rewardedAd = ad;
                        Log.d(TAG, "Rewarded ad loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        isLoadingRewardedAd = false;
                        rewardedAd = null;
                        Log.e(TAG, "Rewarded ad failed to load: " + adError.getMessage());
                    }
                });
    }

    private void showRewardedAdForIndex(final int idx) {
        if (rewardedAd == null) {
            Toast.makeText(this, "এড এখনো লোড হয়নি, একটু পর আবার চেষ্টা করুন", Toast.LENGTH_SHORT).show();
            notifyJs("onRewardAdFailed", idx);
            loadRewardedAd();
            return;
        }

        rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                rewardedAd = null;
                loadRewardedAd(); // পরের বার দেখানোর জন্য আগে থেকেই লোড করে রাখা
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                rewardedAd = null;
                notifyJs("onRewardAdFailed", idx);
                loadRewardedAd();
            }
        });

        rewardedAd.show(this, rewardItem -> {
            // ইউজার সম্পূর্ণ এড দেখেছে — এখন JS-কে জানিয়ে স্টার যোগ করা হবে
            notifyJs("onRewardAdEarned", idx);
        });
    }

    private void notifyJs(final String jsFunction, final int idx) {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(jsFunction + "(" + idx + ");", null);
            }
        });
    }

    @Override
    protected void onPause() {
        if (adViewBanner != null) {
            adViewBanner.pause();
        }
        if (adViewInline != null) {
            adViewInline.pause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adViewBanner != null) {
            adViewBanner.resume();
        }
        if (adViewInline != null) {
            adViewInline.resume();
        }
    }

    @Override
    protected void onDestroy() {
        if (adViewBanner != null) {
            adViewBanner.destroy();
        }
        if (adViewInline != null) {
            adViewInline.destroy();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
