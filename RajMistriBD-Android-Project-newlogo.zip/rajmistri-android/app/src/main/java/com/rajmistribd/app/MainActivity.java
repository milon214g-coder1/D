package com.rajmistribd.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "RajMistriBD";
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PERMISSION_REQUEST_CODE = 4321;
    private static final int FILE_CHOOSER_REQUEST_CODE = 5150;

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;

    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private long backPressedAt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Switch from splash theme to the normal app theme before inflating.
        setTheme(R.style.Theme_RajMistri);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        progressBar = findViewById(R.id.progressBar);

        requestNeededPermissions();
        setupWebView();

        swipeRefresh.setOnRefreshListener(() -> webView.reload());

        if (isNetworkAvailable()) {
            webView.loadUrl(APP_URL);
        } else {
            showNoInternetDialog();
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // প্রথমে ওয়েব অ্যাপকে জিজ্ঞেস করা হয় ভেতরে কোনো মডাল/ওভারলে খোলা আছে কিনা,
                // বা ইন-অ্যাপ নেভিগেশন স্ট্যাকে পেছনে যাওয়ার কিছু আছে কিনা। থাকলে সেটাই হ্যান্ডেল
                // করবে (true রিটার্ন করবে) — তখন অ্যাপ থেকে বের হবে না।
                webView.evaluateJavascript(
                        "(function(){ try { return typeof handleAndroidBack==='function' ? handleAndroidBack() : false; } catch(e){ return false; } })();",
                        value -> {
                            boolean handledInPage = "true".equals(value);
                            if (handledInPage) return;

                            if (webView.canGoBack()) {
                                webView.goBack();
                            } else {
                                if (backPressedAt + 2000 > System.currentTimeMillis()) {
                                    finish();
                                } else {
                                    Toast.makeText(MainActivity.this, R.string.exit_confirm, Toast.LENGTH_SHORT).show();
                                    backPressedAt = System.currentTimeMillis();
                                }
                            }
                        }
                );
            }
        });
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void setupWebView() {
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClientCompat() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(@NonNull WebView view, @NonNull WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(@NonNull WebView view, @NonNull WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null) return false;

                if (scheme.equals("http") || scheme.equals("https")) {
                    // Keep app traffic inside the WebView; open other https links externally
                    // only if they leave the app's own host.
                    if ("appassets.androidplatform.net".equals(uri.getHost())) {
                        return false;
                    }
                    view.loadUrl(uri.toString());
                    return true;
                }

                // tel:, mailto:, whatsapp:, geo: etc -> hand off to the system.
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.w(TAG, "No app found to handle: " + uri);
                }
                return true;
            }

            @Override
            public void onPageFinished(@NonNull WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress >= 100) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            // Gallery + camera picker for <input type="file" accept="image/*">
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallbackParam,
                                              FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackParam;

                // ক্যামেরা ইন্টেন্ট সেটআপ করার সময় কোনো সমস্যা হলেও (FileProvider/storage
                // সংক্রান্ত) যেন পুরো ফাংশনটা ক্র্যাশ না করে — শুধু ক্যামেরা অপশনটা বাদ
                // দিয়ে গ্যালারি অপশন দিয়ে এগিয়ে যায়।
                Intent takePictureIntent = null;
                if (hasCameraPermission()) {
                    try {
                        File photoFile = createImageFile();
                        if (photoFile != null) {
                            cameraPhotoPath = "file:" + photoFile.getAbsolutePath();
                            Uri photoUri = FileProvider.getUriForFile(MainActivity.this,
                                    getApplicationContext().getPackageName() + ".fileprovider", photoFile);
                            takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "Camera intent setup failed, continuing with gallery only", ex);
                        takePictureIntent = null;
                    }
                }

                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("image/*");
                contentSelectionIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "ছবি নির্বাচন করুন");
                if (takePictureIntent != null) {
                    chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{takePictureIntent});
                }

                try {
                    startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    // chooser খোলা যায়নি — সাধারণ গ্যালারি ইন্টেন্ট দিয়ে আরেকবার চেষ্টা
                    Log.e(TAG, "Could not open chooser, falling back to plain gallery intent", e);
                    try {
                        startActivityForResult(contentSelectionIntent, FILE_CHOOSER_REQUEST_CODE);
                    } catch (Exception e2) {
                        // এটাও ব্যর্থ হলে অ্যাপ বন্ধ না করে শুধু জানিয়ে দেওয়া হয়, আর JS-এর
                        // ফাইল-পিকার প্রমিসটা resolve করে দেওয়া হয় যাতে সেটা আটকে না থাকে
                        Log.e(TAG, "Could not open any image picker", e2);
                        Toast.makeText(MainActivity.this, "ছবি বাছাইয়ের কোনো অ্যাপ খুঁজে পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
                        if (filePathCallback != null) {
                            filePathCallback.onReceiveValue(null);
                            filePathCallback = null;
                        }
                    }
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // Auto-grant in-page permission prompts (e.g. getUserMedia) that map to
                // permissions we already hold; otherwise deny.
                runOnUiThread(() -> {
                    ArrayList<String> granted = new ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && hasCameraPermission()) {
                            granted.add(resource);
                        }
                    }
                    if (!granted.isEmpty()) {
                        request.grant(granted.toArray(new String[0]));
                    } else {
                        request.deny();
                    }
                });
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "ফাইল ডাউনলোড করা যায়নি", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            try {
                if (resultCode == RESULT_OK) {
                    if (data == null || (data.getData() == null && data.getClipData() == null)) {
                        // Photo was taken with the camera.
                        if (cameraPhotoPath != null) {
                            results = new Uri[]{Uri.parse(cameraPhotoPath)};
                        }
                    } else if (data.getClipData() != null) {
                        // Multiple images selected from the gallery.
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else {
                        String dataString = data.getDataString();
                        if (dataString != null) {
                            results = new Uri[]{Uri.parse(dataString)};
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error reading picked image result", e);
                results = null;
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "RAJMISTRI_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) {
            storageDir.mkdirs();
        }
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        ArrayList<String> toRequest = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            toRequest.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!toRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return capabilities != null && (
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    private void showNoInternetDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.no_internet_title)
                .setMessage(R.string.no_internet_message)
                .setCancelable(false)
                .setPositiveButton(R.string.retry, (dialog, which) -> {
                    if (isNetworkAvailable()) {
                        webView.loadUrl(APP_URL);
                    } else {
                        showNoInternetDialog();
                    }
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
