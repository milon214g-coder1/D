/**
 * RajMistri BD — পাসওয়ার্ড রিসেট Cloud Function
 * ============================================================
 * কেন এই ফাইলটা দরকার?
 * অ্যাডমিন প্যানেল আর ইউজার অ্যাপ — দুটোই Firebase-এর "client SDK" ব্যবহার করে।
 * নিরাপত্তার কারণে client SDK দিয়ে অন্য কারো Firebase Auth পাসওয়ার্ড (পুরনোটা না জেনে)
 * সরাসরি বদলানো যায় না — এটা ইচ্ছাকৃতভাবেই আটকানো, যাতে কেউ অন্য কারো একাউন্ট
 * হাইজ্যাক করতে না পারে। এই কাজটা শুধু "Admin SDK" (সার্ভার সাইড) দিয়েই করা সম্ভব।
 * তাই এই একটা ছোট Cloud Function ব্যবহার করা হচ্ছে, যেটা শুধুমাত্র অ্যাডমিন প্যানেল
 * থেকে (যাচাই করে) কল হবে এবং আসল পাসওয়ার্ড বদলে দেবে।
 *
 * ডিপ্লয় করার নিয়ম নিচে DEPLOY.md ফাইলে বিস্তারিত লেখা আছে।
 */
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

const db = admin.database();

// এই ইমেইলটাই একমাত্র "অ্যাডমিন" হিসেবে গণ্য হবে — অ্যাডমিন প্যানেলে যে
// ADMIN_EMAIL ব্যবহার হয়েছে ঠিক সেটাই এখানে বসাতে হবে
const ADMIN_EMAIL = "milon01791310431@gmail.com";

exports.adminResetUserPassword = functions.https.onCall(async (data, context) => {
  // ১) কলকারী আসলেই লগইন করা অ্যাডমিন কিনা যাচাই
  if (!context.auth || context.auth.token.email !== ADMIN_EMAIL) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "শুধুমাত্র অ্যাডমিন এই কাজটি করতে পারবেন।"
    );
  }

  const requestId = (data && data.requestId || "").trim();
  const email = (data && data.email || "").trim().toLowerCase();
  const newPassword = (data && data.newPassword || "").trim();

  if (!requestId || !email || !newPassword) {
    throw new functions.https.HttpsError("invalid-argument", "requestId, email ও newPassword আবশ্যক।");
  }
  if (newPassword.length < 6) {
    throw new functions.https.HttpsError("invalid-argument", "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
  }

  // ২) অনুরোধটি এখনো বৈধ (pending ও মেয়াদ শেষ হয়নি) কিনা যাচাই
  const reqSnap = await db.ref("passwordResetRequests/" + requestId).get();
  if (!reqSnap.exists()) {
    throw new functions.https.HttpsError("not-found", "এই রিসেট অনুরোধ খুঁজে পাওয়া যায়নি।");
  }
  const reqData = reqSnap.val();
  if (reqData.status !== "pending") {
    throw new functions.https.HttpsError("failed-precondition", "এই অনুরোধ ইতিমধ্যে প্রসেস করা হয়েছে।");
  }
  if (reqData.expiresAt && reqData.expiresAt <= Date.now()) {
    throw new functions.https.HttpsError("failed-precondition", "এই অনুরোধের ৪৮ ঘণ্টার মেয়াদ শেষ হয়ে গেছে।");
  }
  if (reqData.email !== email) {
    throw new functions.https.HttpsError("invalid-argument", "ইমেইল মিলছে না।");
  }

  // ৩) ঐ ইমেইল দিয়ে Firebase Auth-এ ইউজার খুঁজে বের করা
  let userRecord;
  try {
    userRecord = await admin.auth().getUserByEmail(email);
  } catch (e) {
    throw new functions.https.HttpsError("not-found", "এই জিমেইলে কোনো Firebase একাউন্ট পাওয়া যায়নি।");
  }

  // ৪) আসল পাসওয়ার্ড পরিবর্তন — এটাই মূল কাজ, Admin SDK ছাড়া সম্ভব না
  await admin.auth().updateUser(userRecord.uid, { password: newPassword });

  const now = Date.now();

  // ৫) অনুরোধের স্ট্যাটাস আপডেট + ইউজারের একাউন্টে নোটিফিকেশন লেখা
  //    (ইউজার অ্যাপ লগইন অবস্থায় থাকলে সাথে সাথে পপআপে নতুন পাসওয়ার্ড দেখাবে)
  await Promise.all([
    db.ref("passwordResetRequests/" + requestId).update({
      status: "confirmed",
      handledAt: now,
      resetUid: userRecord.uid,
    }),
    db.ref("users/" + userRecord.uid + "/passwordResetNotice").set({
      newPassword,
      resetAt: now,
      requestId,
      seen: false,
    }),
  ]);

  return { ok: true, uid: userRecord.uid };
});
