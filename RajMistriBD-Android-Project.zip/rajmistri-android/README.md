# RajMistri বিডি — Android অ্যাপ (WebView প্রজেক্ট)

এটি একটি সম্পূর্ণ **Android Studio compatible প্রজেক্ট**। আপনার `rajmistri-bd-1.html` ফাইলটিকে
`app/src/main/assets/index.html` হিসেবে ভেতরে রাখা হয়েছে এবং একটি প্রফেশনাল native
WebView wrapper (splash screen, লঞ্চার আইকন, ছবি আপলোড/ক্যামেরা সাপোর্ট, ইন্টারনেট
চেক, ব্যাক বাটন হ্যান্ডলিং সহ) বানানো হয়েছে।

## Package তথ্য
- **Package name (applicationId):** `com.rajmistribd.app`
- **App name:** RajMistri বিডি
- **Version:** 1.0.0 (versionCode 1)
- minSdk 23 (Android 6.0+), targetSdk 34

## "Android Code Studio" (Android Code Studio) দিয়ে বিল্ড করার নিয়ম
1. এই zip ফাইলটি আপনার ফোনে ডাউনলোড করে **Extract/Unzip** করুন (একটি ফোল্ডার তৈরি হবে)।
2. Android Code Studio অ্যাপ খুলে **"Open existing project"** চাপুন।
3. Extract করা `rajmistri-android` ফোল্ডারটি সিলেক্ট করুন।
4. প্রথমবার Gradle sync হতে কিছুক্ষণ সময় লাগবে (ইন্টারনেট লাগবে — dependency ডাউনলোড হবে)।
5. Sync শেষ হলে **Build → Build APK / Generate Signed Bundle/APK** অপশনে যান।
   - টেস্ট করার জন্য: **Debug APK** বানান, ফোনে ইনস্টল করে চেক করুন।
   - Play Store-এ আপলোডের জন্য: **Generate Signed APK/AAB** ব্যবহার করে নিজের
     keystore দিয়ে সাইন করুন (নিচে দেখুন)।

## Play Store-এ আপলোডের আগে যা যা করতে হবে
1. **নিজের Keystore বানান ও সাইন করুন** — একবার হারিয়ে ফেললে ভবিষ্যতে আপডেট আপলোড
   করা যাবে না, তাই keystore ফাইল ও পাসওয়ার্ড নিরাপদে সংরক্ষণ করুন।
2. **Package name চূড়ান্ত করুন** — বর্তমানে `com.rajmistribd.app` রাখা হয়েছে; Play
   Console-এ এটি একবার সেট হলে আর বদলানো যাবে না, তাই চাইলে এখনই
   `applicationId` (app/build.gradle) পরিবর্তন করুন।
3. **App icon** — `playstore-icon-512.png` ফাইলটি Play Console-এ hi-res icon হিসেবে
   আপলোড করতে পারবেন (চাইলে নিজের ডিজাইন করা লোগো দিয়ে
   `app/src/main/res/mipmap-*/ic_launcher*.png` ফাইলগুলো replace করে দিন)।
4. **Privacy Policy লিংক** — অ্যাপে Firebase Auth/Database ব্যবহার হওয়ায় Play
   Console এ একটি Privacy Policy পেজের লিংক দিতে হবে (নিজের ওয়েবসাইটে বা Google
   Sites-এ ফ্রি বানানো যায়)।
5. **Data safety form** পূরণ করতে হবে (Firebase-এ কী কী ডেটা সংরক্ষণ হয় তার ভিত্তিতে)।
6. Screenshots (কমপক্ষে ২টি ফোন স্ক্রিনশট), feature graphic, short/full description
   বাংলা ও ইংরেজিতে রেডি রাখুন।

## এই প্রজেক্টে যা যা রাখা হয়েছে
- `app/src/main/assets/index.html` — আপনার আসল অ্যাপ (অপরিবর্তিত)
- `MainActivity.java` — WebView লোড করে, নিরাপদে `https://appassets.androidplatform.net/`
  origin থেকে (তাই Firebase/localStorage/IndexedDB ঠিকভাবে কাজ করবে)
- ছবি আপলোড ইনপুট (`<input type="file">`) থেকে গ্যালারি + ক্যামেরা দুটোই বেছে নেওয়ার অপশন
- Splash screen (লোগো + ব্র্যান্ড কালার #3949AB)
- Adaptive লঞ্চার আইকন (সব ডেনসিটিতে)
- ইন্টারনেট না থাকলে reconnect ডায়ালগ
- Pull-to-refresh
- Back বাটনে WebView history navigation + দুইবার back চাপলে exit

## পরে পরিবর্তন করতে চাইলে
- অ্যাপের HTML/JS আপডেট করতে চাইলে শুধু `app/src/main/assets/index.html` replace
  করে আবার বিল্ড করলেই হবে।
- অ্যাপের নাম/রঙ বদলাতে `app/src/main/res/values/strings.xml` ও `colors.xml` দেখুন।
